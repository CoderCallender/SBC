README for GRB-29364_B.zip

Company Part Number: 170-29364 REV B

Date: Mon, 26 Sep 2022 10:06:05 GMT

NXP Semiconductors
6501 William Cannon Drive West
Austin, TX 78735-8598


CAD Engineer
============
Company Contact     : [full_name]
Work Phone          : 512-895-XXXX
Email               : [email]@nxp.com

CAD Manager
===========
Company Contact     : Radu Maier
Work Phone          : ---
Email               : radu.maier@nxp.com

Manufacturing Program Manager
=============================
Company Contact     : Bobby Zhao
Work Phone          : 021-28937271
Email               : bobby.zhao@nxp.com

Product Engineer
================
Company Contact     : Leo Pan
Work Phone          : 86-021-2893-7765
Email               : leo.pan@nxp.com

Design Engineer
================
Company Contact     : Annanya Gupta
Work Phone          : ---
Email               : annanya.gupta@nxp.com

Design for Manufacturing Engineer
=================================
Company Contact     : Rosalia Gonzalez
Work Phone          : +52(33) 3283-2100 x2267
Email               : HardwareSolutionsCoE-PCB@NXP1.onmicrosoft.com
