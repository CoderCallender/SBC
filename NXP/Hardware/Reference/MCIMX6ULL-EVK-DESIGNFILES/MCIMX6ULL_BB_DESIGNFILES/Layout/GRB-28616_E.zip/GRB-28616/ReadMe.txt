README for GRB-28616_E.zip

Company Part Number: 170-28616 REV E

Date: Sun, 23 Apr 2023 05:52:12 GMT

NXP Semiconductors
6501 William Cannon Drive West
Austin, TX 78735-8598


All EQs are to be sent to the ENTIRE team listed below.

CAD Engineer
============
Company Contact     : [full_name]
Work Phone          : 512-895-XXXX
Email               : [email]@nxp.com

CAD Manager
===========
Company Contact     : Ionut Manolescu
Work Phone          : ---
Email               : ionut.manolescu@nxp.com

Manufacturing Program Manager
=============================
Company Contact     : Bobby Zhao
Work Phone          : 021-28937271
Email               : bobby.zhao@nxp.com

Product Engineer
================
Company Contact     : Leo Pan
Work Phone          : 86-021-2893-7765
Email               : leo.pan@nxp.com

Design Engineer
================
Company Contact     : Bhaskar Nermati Reddy
Work Phone          : 512-895-XXXX
Email               :  bhaskarnermati.reddy@nxp.com

Design for Manufacturing Engineer
=================================
Company Contact     : Rosalia Gonzalez
Work Phone          : +52(33) 3283-2100 x2267
Email               : HWCOEPCBSolutions@msteams.nxp.com
